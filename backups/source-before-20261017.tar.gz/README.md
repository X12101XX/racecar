# 穿越火线（JSAI2025 算法应用赛）无人车程序

面向「全球校园人工智能算法精英大赛 · 算法应用赛 · 穿越火线」赛题的一整套可运行实现：
**视觉 + 激光雷达 + IMU 感知 → 锥桶地图 → 避障规划 → 路径跟踪 → 任务状态机**，
既能在本地仿真里一键复现，也能直接部署到 Atlas 200I DK A2 / ROS2 Humble 小车上。

> 线上赛不抽色卡：程序默认按参数直接跑 **路线 A（蓝卡路线：据点A → 营地A）**
> 或 **路线 B（红卡路线：据点B → 营地B）**；线下/总决赛把 `use_card:=true` 打开，
> 摄像头识别蓝/红色卡后自动选路线并语音播报。

---

## 1. 快速开始（本地仿真，无需 ROS2）

**先跑这一条**：一键自检（环境 + 28 项测试 + 路线 A 短仿真，约 2~3 分钟）

```bash
bash tools/selfcheck.sh
```

看到 `自检通过 ✅` 就说明整套程序在当前机器上可用。其余常用命令：

```bash
bash tools/run_sim_demo.sh 3          # 两条路线各跑一遍，生成视频/轨迹图
python3 -m sim.cli --route B --seed 5 --prior blue   # 单次运行（红卡路线 + 公布位置）
python3 -m sim.stress --route both --seeds 6 --jobs 6 --max-time 150 --prior blue
```

```bash
# 跑一条路线（随机生成锥桶布局，输出轨迹图 / 视频 / 指标）
python3 -m sim.cli --route A --seed 2 --outdir output/demoA
python3 -m sim.cli --route B --seed 2 --outdir output/demoB

# 两条路线一起跑（生成演示视频）
bash tools/run_sim_demo.sh 2

# 批量随机场地测试（成功率、用时、撞锥统计）
python3 -m sim.stress --route both --seeds 10 --jobs 8 --outdir output/stress
```

只用 Python3 + numpy（仿真里图像处理自动退化为 scipy/numpy 后端；
车上装了 OpenCV 时自动走 cv2 后端，代码完全一致）。

产物：`video.mp4`（相机画面 + 感知框 + 俯视图轨迹）、`map.png`、`summary.json`、
`events.json`（完整事件流：识别、播报、到点、停留、穿越、撞锥、停车）。

## 2. 部署到小车（ROS2 Humble）

```bash
# 一键组装 + 推送 + 编译（默认小车 davinci-mini@192.168.5.100）
bash tools/deploy.sh --push --build

# 小车上：1) 启动原有底盘/雷达/IMU/相机   2) 接口自检   3) 跑任务
ros2 launch racecar Run_car_one.launch.py
ros2 run racecar_mission preflight          # 上车自检：话题/图像编码/雷达/配置，出一份 PASS/FAIL 报告
ros2 launch racecar_mission mission.launch.py route:=A
```

详细步骤、话题映射、参数标定见 [docs/02_车辆部署指南.md](docs/02_车辆部署指南.md)。

## 3. 两条路线怎么定义

| | 路线 A（蓝卡） | 路线 B（红卡） |
| --- | --- | --- |
| 据点 | 据点 A（左上，蓝色框） | 据点 B（左下，红色框） |
| 停留 | 3 秒 | 3 秒 |
| 穿越雷区 | 从上方进入，斜穿到下方 | 从下方进入，斜穿到上方 |
| 终点 | 营地 A（右下，蓝色） | 营地 B（右上，红色） |
| 关键参数 | `config/route_a.json` | `config/route_b.json` |

两条路线共用同一套感知/规划/控制代码，只有**目标区域、进入/退出点、走廊范围**不同，
所以赛前拿到场地尺寸和封锁线位置后，只需要改 `config/field.json` 和对应的
`config/route_*.json`。

## 4. 目录结构

```
racelib/         算法核心（无 ROS 依赖，仿真与实车共用同一份代码）
  field.py         场地与赛道模型（据点/营地/雷区/封锁线/先验锥桶）
  vision.py        色卡识别、锥桶颜色分类、地面色块确认（OpenCV 语义）
  lidarproc.py     点云聚类 → 圆拟合锥桶 / 直线拟合墙面
  fusion.py        多帧锥桶地图 + 相机颜色标注
  localization.py  里程计 + IMU + 墙面距离修正定位
  gridmap.py       栅格代价地图（硬障碍 + 软代价）
  planner.py       封锁线缝隙分析 + A* + 路径平滑 + 车辆足迹校验
  control.py       纯跟踪控制、速度规划、安全监控
  mission.py       任务状态机（识别→播报→据点→停留3s→穿越雷区→营地→停车）
sim/             本地仿真：场地随机化、相机成像、雷达射线、IMU/里程计、批量测试
ros2_ws/          小车端 ROS2 工作空间（racelib 包 + racecar_mission 包）
config/           场地/车辆/视觉/规划/两条路线参数（JSON，仿真与实车共用）
tools/            deploy.sh（部署）、run_sim_demo.sh（演示）、画图脚本
docs/             架构与算法、部署指南、测试报告（可直接改写成技术文档案例）
tests/            单元测试与端到端测试
```

## 5. 任务流程（与赛题一一对应）

1. **识别**：`use_card=true` 时用摄像头找蓝/红色卡（A4 比例 + 面积占比），蓝→A、红→B；
   线上赛不抽色卡则直接读取 `route` 参数。
2. **播报**：语音播报（`espeak-ng`）并发布 `/mission/announce` 与显示文本：
   “我将前往路线A，到达据点A并穿越雷区返回营地A。”
3. **到据点**：A* 规划到据点中心，进区判定 = 里程计在 1×1m 区内 **且** 摄像头在画面
   下方确认到对应颜色地贴（双条件，避免误判）。
4. **停留 3 秒**：停车计时，实测停留时间写入报告。
5. **穿越雷区**：封锁线缝隙动态规划（选缝）→ A* 输出路径 → 纯跟踪行驶；
   途中持续融合雷达锥桶与相机颜色，识别到红锥（地雷）按障碍规避。
6. **到营地停车**：进入营地色块区域后主动刹车并记录总用时、撞锥次数、罚时。

## 6. 安全与兜底（比赛中很容易被忽略的部分）

- 贴身保护层：车体矩形与已建图锥桶的间隙 < 10cm 时倒车脱离，10~20cm 时限速；
  倒车前后向净空不足则原地转向最空旷方向脱困。
- 雷达前向 40° 内出现 < 14cm 障碍立即急停；控制指令超时（>0.4s）自动归零。
- 规划失败时**绝不盲目前进**：先原地对准目标，只有前方 > 0.8m 空旷才慢速蠕动，
  同时把“卡点”标记为临时禁区，避免反复蹭同一个地方。
- 阶段超时（据点 60s / 雷区 240s）自动停车并写入失败原因，不会撞着锥桶一直冲。
- 撞锥识别：IMU 比力突变判撞击，用画面下方蓝/红占比判定颜色——
  撞红锥（地雷）按赛题判失败并停车，撞蓝锥记 5 秒罚时。

## 7. 本地验证状态（真实数据，诚实说明）

批量随机场地测试（每次 16 个随机场地、两条路线各半、单次仿真上限 150 s）：

| 测试条件 | 成功率 | 有效用时（平均/最快/最慢） | 撞红锥（地雷）轮次 | 碰墙轮次 | 锥桶召回/精度 |
| --- | --- | --- | --- | --- | --- |
| 完全靠在线感知（无先验） | 13/16 = **81%** | 43.2 / 27.6 / 66.5 s | **0** | 0 | 0.89 / 0.87 |
| **有赛前公布位置**（`prior=blue`） | 15/16 = **94%** | 39.9 / 29.7 / 58.8 s | **0** | 0 | 0.98 / 0.89 |

两批测试中撞到地雷的轮次都是 **0**（地雷位置随机且未事先告知）；
剩余失败轮次只出现在无先验条件，原因是雷区密集处反复调整导致超时。
演示视频（路线 A 29.7 s / 路线 B 32.5 s，均零碰撞、召回 0.95~1.0）：
[路线A](output/demo_routeA/video.mp4)、[路线B](output/demo_routeB/video.mp4)。

测试全部通过（42 项，含两条路线的端到端任务、ROS2 节点/自检/标定逻辑、
场地与阈值工具、以及**对照官方消息定义的接口契约测试**）：

```bash
python3 -m unittest discover -s tests -v     # 44 项测试 ~95 s
bash tools/check_py310.sh                    # 用"小车同款" Python 3.10 + numpy 1.21 再跑一遍
```

其中 `tests/test_ros_node_smoke.py` 用桩件模拟 rclpy/消息类型，验证了
话题自动探测、参数（路线/是否发指令）、播报发布、诊断、RViz 标记，
以及 `preflight` 自检节点的报告逻辑，把"上车才发现接口写错"的风险提前挡掉一部分
（**桩件不能替代真车联调**，上车第一件事仍是 `ros2 run racecar_mission preflight`）。

已完成并验证：感知链路（相机成像 → HSV → 连通域 → 锥桶/色卡）、雷达聚类与融合、
定位（仿真中定位误差 < 3 cm）、缝隙决策 + A* + 纯跟踪 + 安全兜底、状态机全流程。

**未完成（需要小车在场）**：真车话题名与标定（相机内外参、地面距离系数）、
底盘最大速度与转向响应、语音模块、现场光照下的 HSV 阈值，
以及 ROS2 节点在真车上的首次联调（本机没有 rclpy，无法运行）。
这些都在 [docs/02_车辆部署指南.md](docs/02_车辆部署指南.md) 里给了自检与标定步骤。

## 8. 文档索引

| 文档 | 用途 |
| --- | --- |
| [docs/01_系统架构与算法.md](docs/01_系统架构与算法.md) | 架构与算法细节（技术文档"算法设计"章节底稿） |
| [docs/00_技术文档首页模板.md](docs/00_技术文档首页模板.md) | 技术文档封面模板 + 章节结构建议 + 可直接引用的图表清单 |
| [docs/02_车辆部署指南.md](docs/02_车辆部署指南.md) | 上车部署、话题映射、四项标定、常见问题 |
| [docs/03_测试报告.md](docs/03_测试报告.md) | 批量随机场地测试的逐轮数据与结论 |
| [docs/04_技术文档案例.md](docs/04_技术文档案例.md) | 7 个技术案例（对应评分表：创新性/实用性/复杂度/复现性） |
| [output/route_ab_overview.png](output/route_ab_overview.png) | 两条路线示意图 |
| [output/field_layout.png](output/field_layout.png) | 当前场地布局（由 `tools/setup_field.py` 生成/校验） |
| [output/demo_routeA/video.mp4](output/demo_routeA/video.mp4) | 路线 A 完整演示视频（相机 + 俯视图 + 感知框） |
| [output/demo_routeB/video.mp4](output/demo_routeB/video.mp4) | 路线 B 完整演示视频 |

## 9. 赛前改场地 / 现场标定（两个常用工具）

```bash
# 1) 现场量到尺寸后，一键重算布局 + 检查自洽（区域不越界、雷区 4m、封锁线间隔 1.5m）
python3 tools/setup_field.py --length 7.5 --width 4.2          # 只看结果并出布局图
python3 tools/setup_field.py --length 7.5 --width 4.2 --apply  # 写回 field.json 与两条路线

# 2) 现场光照下标定颜色阈值（拿一张有锥桶/色卡的照片）
python3 tools/tune_hsv.py --image 现场照片.jpg --debug output/hsv_debug.png
python3 tools/tune_hsv.py --image 现场照片.jpg --apply         # 满意后写回 vision.json

# 3) 赛前拿到公布的锥桶坐标后一键填进配置（自动按最近封锁线分组）
python3 tools/setup_field.py --apply --cones "2.05,1.2 1.95,2.4 3.5,0.8 5.0,2.2" \
                                     --mines "2.6,2.3 4.1,0.9"
```

两个工具都会先给可视化结果（布局图 / 颜色掩码图），肉眼确认后再 `--apply`。
车端还有两个命令：`ros2 run racecar_mission preflight`（上车自检，含用雷达实测场地尺寸
与配置比对）和 `ros2 run racecar_mission calibrate_drive`（底盘死区/增益标定）。
