#!/usr/bin/env bash
# 一键自检：跑测试 + 短仿真，确认整套程序在当前机器上可用。
#
#   bash tools/selfcheck.sh          # 测试 + 路线A短仿真（约 2~3 分钟）
#   bash tools/selfcheck.sh --full   # 再跑两条路线完整演示（会生成视频）
set -uo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"
mkdir -p output

fail=0
echo "==== 1/3 环境检查 ===="
python3 tools/check_env.py || fail=1

echo
echo "==== 2/3 单元 + 端到端测试（28 项）===="
python3 -m unittest discover -s tests 2>&1 | tail -4 || fail=1

echo
echo "==== 3/3 仿真：路线A（随机场地 seed=3）===="
python3 -u -m sim.cli --route A --seed 3 --no-video --max-time 120 \
    --outdir output/selfcheck_A > output/selfcheck_A.log 2>&1 || fail=1
python3 tools/report_one_run.py output/selfcheck_A || fail=1

if [[ "${1:-}" == "--full" ]]; then
  echo
  echo "==== 附加：两条路线完整演示（生成视频）===="
  bash tools/run_sim_demo.sh 3 || fail=1
fi

echo
if [[ $fail -eq 0 ]]; then
  echo "自检通过 ✅  产物在 output/ 下（video.mp4 / map.png / summary.json / events.json）"
else
  echo "自检有问题 ❌ 把上面的输出发我，我来定位"
fi
exit $fail
