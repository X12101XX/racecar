#!/usr/bin/env bash
# 本地跑两条路线的完整演示（生成视频、轨迹图、指标 JSON）。
#
#   bash tools/run_sim_demo.sh            # 默认 seed=1，并注入"赛前公布的封锁线位置"
#   bash tools/run_sim_demo.sh 5          # 指定随机种子
#   PRIOR=none bash tools/run_sim_demo.sh # 完全靠在线感知（更难）
set -euo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_DIR"
SEED="${1:-1}"
PRIOR="${PRIOR:-blue}"
for ROUTE in A B; do
  echo "==> 仿真路线 $ROUTE（随机场地 seed=$SEED，先验=$PRIOR）"
  python3 -m sim.cli --route "$ROUTE" --seed "$SEED" \
      --prior "$PRIOR" --outdir "output/demo_route${ROUTE}" --fps 8
done
echo "产物在 output/demo_routeA/ 与 output/demo_routeB/（video.mp4 / map.png / summary.json）"
