#!/usr/bin/env bash
# 把算法核心 + ROS2 节点打包/部署到小车。
#
#   bash tools/deploy.sh                 # 只在本机组装工作空间（不联网）
#   bash tools/deploy.sh --push          # 组装并 rsync 到小车
#   bash tools/deploy.sh --push --build  # 再在小车上 colcon build
#   bash tools/deploy.sh --push --build --run A   # 再启动任务（路线 A）
#
# 小车默认地址可用环境变量覆盖：CAR_HOST=custom@192.168.5.100 CAR_DIR=~/racecar_crossfire
set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CAR_HOST="${CAR_HOST:-davinci-mini@192.168.5.100}"
CAR_DIR="${CAR_DIR:-~/racecar_crossfire}"
WS_DIR="$REPO_DIR/ros2_ws"

DO_PUSH=0
DO_BUILD=0
RUN_ROUTE=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --push) DO_PUSH=1; shift ;;
    --build) DO_BUILD=1; shift ;;
    --run) RUN_ROUTE="${2:-A}"; shift 2 ;;
    *) echo "未知参数：$1"; exit 2 ;;
  esac
done

echo "==> 1/3 组装工作空间（同步 racelib 与配置文件）"
rm -rf "$WS_DIR/src/racelib/racelib"
mkdir -p "$WS_DIR/src/racelib/racelib"
cp "$REPO_DIR"/racelib/*.py "$WS_DIR/src/racelib/racelib/"
cp "$REPO_DIR"/config/*.json "$WS_DIR/src/racecar_mission/config/"
echo "    racelib: $(ls "$WS_DIR/src/racelib/racelib" | wc -l) 个模块"
echo "    配置:    $(ls "$WS_DIR/src/racecar_mission/config" | tr '\n' ' ')"

if [[ $DO_PUSH -eq 1 ]]; then
  echo "==> 2/3 推送到小车 $CAR_HOST:$CAR_DIR"
  ssh "$CAR_HOST" "mkdir -p $CAR_DIR"
  rsync -az --delete \
    --exclude build --exclude install --exclude log \
    "$WS_DIR/" "$CAR_HOST:$CAR_DIR/ros2_ws/"
  echo "    完成。小车上的工作空间：$CAR_DIR/ros2_ws"
else
  echo "==> 2/3 跳过推送（加 --push 才会同步到小车）"
fi

if [[ $DO_BUILD -eq 1 ]]; then
  echo "==> 3/3 在小车上编译"
  ssh "$CAR_HOST" "cd $CAR_DIR/ros2_ws && source /opt/ros/humble/setup.bash && \
      colcon build --symlink-install 2>&1 | tail -5"
fi

if [[ -n "$RUN_ROUTE" ]]; then
  echo "==> 启动任务：路线 $RUN_ROUTE"
  ssh -t "$CAR_HOST" "cd $CAR_DIR/ros2_ws && source /opt/ros/humble/setup.bash && \
      source install/setup.bash && \
      ros2 launch racecar_mission mission.launch.py route:=$RUN_ROUTE"
fi

cat <<'EOF'

小车上再按需执行：
  # 底盘/雷达/IMU/相机（沿用原有启动文件）
  ros2 launch racecar Run_car_one.launch.py
  # 接口自检
  ros2 run racecar_mission probe_topics
  # 跑任务
  ros2 launch racecar_mission mission.launch.py route:=A
EOF
