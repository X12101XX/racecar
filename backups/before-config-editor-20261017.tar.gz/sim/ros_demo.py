"""Real ROS2 end-to-end simulation: world -> sensors -> mission -> gateway -> bicycle.
Runs real rclpy/messages in isolated Docker. World has truth; controller gets sensor topics only.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan, Imu, Image
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Bool
from racelib.config import load_all
from racelib.field import Field
from racelib.vision import CameraModel
from .world import SimWorld, SimRobotConfig, generate_cones
from .scenarios import demo_cones
from .camera import CameraRenderer


class WorldNode(Node):
    def __init__(self,args):
        super().__init__('crossfire_sim_world')
        self.args=args;self.out=Path(args.outdir);self.out.mkdir(parents=True,exist_ok=True)
        self.cfg=load_all(route=args.route);f=Field.from_config(self.cfg['field'])
        (self.out/'events_live.jsonl').write_text('')
        robot=self.cfg['robot']
        physical=SimRobotConfig(drive_model='ackermann',length=float(robot.get('geometry.length_m',.42)),width=float(robot.get('geometry.width_m',.30)),wheelbase=float(robot.get('geometry.wheel_base_m',.30)),max_steer=float(robot.get('drive.max_steer_rad',.52)))
        self.world=SimWorld(f,demo_cones() if args.scenario=="demo" else generate_cones(f,np.random.default_rng(args.seed)),np.random.default_rng(args.seed),
                            robot=physical)
        self.renderer=CameraRenderer(f,CameraModel(width=320,height=240),monochrome=True)
        self.scan=self.create_publisher(LaserScan,'/scan',qos_profile_sensor_data)
        self.imu=self.create_publisher(Imu,'/imu/data',qos_profile_sensor_data)
        self.odom=self.create_publisher(Odometry,'/odom',qos_profile_sensor_data)
        self.image=self.create_publisher(Image,'/usb_cam/image_raw',qos_profile_sensor_data)
        self.create_subscription(Twist,'/crossfire/sim_cmd',self.cmd,1)
        self.create_subscription(String,'/crossfire/mission/state',self.state,10)
        self.create_subscription(String,'/crossfire/mission/events',self.event,10)
        self.create_subscription(String,'/crossfire/gateway_state',self.gate,10)
        self.estop_pub=self.create_publisher(Bool,'/crossfire/estop',1)
        self.received_cmd=0;self.last_cmd=0.;self.command=(0.,0.);self.last_state={};self.events=[]
        self.gateway=[];self.trajectory=[];self.wall0=time.monotonic();self.last=self.wall0
        self.last_image=0.;self.last_scan=0.;self.done=False;self.camp_truth=False
        self.frames=[];self.last_frame=0.;self.last_echo=0.;self.failure_test=None
        self.video_proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1200x650','-r','4','-i','-','-an','-vcodec','libx264','-pix_fmt','yuv420p',str(self.out/'video.mp4')],stdin=subprocess.PIPE)
        self.create_timer(.01,self.tick)

    def cmd(self,msg):
        self.command=(msg.linear.x,msg.angular.z);self.received_cmd+=1;self.last_cmd=time.monotonic()
        if self.failure_test is not None:
            self.failure_test['observations'].append([time.monotonic(),msg.linear.x,msg.angular.z])
    def state(self,msg):
        try:
            d=json.loads(msg.data)
            if 'state' in d:self.last_state=d
        except ValueError:pass
    def event(self,msg):
        try:self.events.append(json.loads(msg.data))
        except ValueError:pass
    def gate(self,msg):
        try:self.gateway.append([time.monotonic(),json.loads(msg.data)])
        except ValueError:pass

    def tick(self):
        now=time.monotonic();dt=min(1.,now-self.last);self.last=now
        # World also models MCU stop after 0.5s with no commands.
        self.world.set_cmd(*(self.command if now-self.last_cmd<.5 else (0.,0.)))
        # Preserve elapsed wall time; substeps maintain the bicycle dynamics stability.
        remaining=dt
        while remaining>1e-7:
            sub=min(.01,remaining);self.world.step(sub);remaining-=sub
        stamp=self.get_clock().now().to_msg();t=self.world.t
        if not (self.args.fault=='scan_drop' and t>4) and now-self.last_scan>=.10:
            q=self.world.lidar_scan(t);m=LaserScan();m.header.stamp=stamp;m.header.frame_id='base_link'
            m.angle_min=float(q.angles[0]);m.angle_max=float(q.angles[-1]);m.angle_increment=float(q.angles[1]-q.angles[0]);m.range_min=.12;m.range_max=12.;m.ranges=q.ranges.astype(float).tolist();self.scan.publish(m);self.last_scan=now
        q=self.world.imu_sample(t);m=Imu();m.header.stamp=stamp;m.header.frame_id='base_link'
        m.orientation.z=math.sin(q.yaw/2);m.orientation.w=math.cos(q.yaw/2)
        m.angular_velocity.z=float(q.yaw_rate);m.linear_acceleration.x=float(q.accel[0]);m.linear_acceleration.y=float(q.accel[1]);m.linear_acceleration.z=float(q.accel[2]);self.imu.publish(m)
        q=self.world.odom_sample(t);m=Odometry();m.header.stamp=stamp;m.header.frame_id='odom';m.child_frame_id='base_link';m.twist.twist.linear.x=float(q.v);m.twist.twist.angular.z=float(q.w);self.odom.publish(m)
        if now-self.last_image>=.2:
            a=self.renderer.render(self.world.cones,self.world.pose);m=Image();m.header.stamp=stamp;m.height=a.shape[0];m.width=a.shape[1];m.encoding='rgb8';m.step=a.shape[1]*3;m.data=a.tobytes();self.image.publish(m);self.last_image=now
        self.trajectory.append([t,*self.world.pose,self.world.v,self.world.w,*self.command])
        if now-self.last_frame>=.25:
            self.save_frame(a if 'a' in locals() else self.renderer.render(self.world.cones,self.world.pose));self.last_frame=now
        camp=self.world.field.zone('camp_a' if self.args.route=='A' else 'camp_b')
        if camp.distance_to_center(self.world.pose)<.25:self.camp_truth=True
        if now-self.last_echo>5:
            print(json.dumps(dict(t=round(t,1),pose=[round(v,2) for v in self.world.pose],state=self.last_state.get('state'),estimate=self.last_state.get('pose'),gate=self.gateway[-1][1] if self.gateway else None,cmd=self.command)),flush=True);self.last_echo=now
        if self.last_state.get('state') in ('DONE','FAILED'):self.done=True

    def save_frame(self,a):
        from PIL import Image as PI,ImageDraw,ImageFont
        canvas=PI.new('RGB',(1200,650),'#10151e');d=ImageDraw.Draw(canvas)
        try:
            d.font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
            small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
        except OSError:
            d.font=ImageFont.load_default();small=d.font
        # Fixed scale layout; all field materials are grey in this online mode.
        scale=75;ox=30;oy=590
        def xy(x,y):return (ox+x*scale,oy-y*scale)
        f=self.world.field
        d.rectangle([xy(0,f.width),xy(f.length,0)],fill='#d8d8d8',outline='white',width=2)
        for name,z in f.zones.items():
            d.rectangle([xy(z.cx-.5,z.cy+.5),xy(z.cx+.5,z.cy-.5)],outline='#505050',width=2);d.text(xy(z.cx-.36,z.cy),{'stronghold_a':'Base A','stronghold_b':'Base B','camp_a':'Camp A','camp_b':'Camp B'}[name],fill='#111111',font=small)
        for c in self.world.cones:
            x,y=xy(c.x,c.y);r=c.radius_base*scale;d.ellipse((x-r,y-r,x+r,y+r),fill='#555555')
        from racelib.geometry import rect_corners
        d.line([xy(p[0],p[1]) for p in rect_corners(*self.world.pose[:2],self.world.robot.length,self.world.robot.width,self.world.yaw)]+[xy(*__import__('racelib.geometry',fromlist=['rect_corners']).rect_corners(self.world.x,self.world.y,self.world.robot.length,self.world.robot.width,self.world.yaw)[0])],fill='#007d9c',width=4)
        if len(self.trajectory)>2:d.line([xy(p[1],p[2]) for p in self.trajectory[::4]],fill='#007d9c',width=2)
        cam=PI.fromarray(a).resize((600,450));canvas.paste(cam,(590,180))
        d.text((30,25),f'ROS2 Humble | Route {self.args.route} | MONOCHROME | ACKERMANN',fill='white')
        d.text((30,65),f't={self.world.t:.1f}s  state={self.last_state.get("state","WAITING")}  collisions={len(self.world.contacts)}',fill='white')
        d.text((30,100),f'command SI: v={self.command[0]:.2f} m/s, w={self.command[1]:.2f} rad/s',fill='white')
        self.frames=[canvas]
        self.video_proc.stdin.write(canvas.tobytes())

    def finish(self,reason):
        s=self.last_state;done=s.get('state')=='DONE'
        summary=dict(route=self.args.route,seed=self.args.seed,transport='real ROS2 Humble DDS',monochrome=True,drive_model='ackermann',
                     final_state=s.get('state'),success=done and self.camp_truth and not self.world.contacts and not self.world.wall_contacts,
                     reached_camp_truth=self.camp_truth,cone_contacts=len(self.world.contacts),wall_contacts=self.world.wall_contacts,
                     sim_time=self.world.t,metrics=s.get('metrics'),received_commands=self.received_cmd,reason=reason)
        (self.out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
        (self.out/'events.json').write_text(json.dumps(self.events,ensure_ascii=False,indent=2))
        (self.out/'gateway.json').write_text(json.dumps(self.gateway,indent=2))
        (self.out/'world.json').write_text(json.dumps([dict(x=c.x,y=c.y,role=c.color,line=c.line) for c in self.world.cones],indent=2))
        with (self.out/'trajectory.csv').open('w') as f:
            w=csv.writer(f);w.writerow(['t','x','y','yaw','v','w','cmd_v','cmd_w']);w.writerows(self.trajectory)
        self.save_frame(self.renderer.render(self.world.cones,self.world.pose))
        if self.frames:
            self.frames[-1].save(self.out/'final.png')
        self.video_proc.stdin.close()
        self.video_proc.wait(timeout=30)
        return summary


def launch_node(executable,params,log,env):
    cmd=['ros2','run','racecar_mission',executable,'--ros-args']
    for k,v in params.items():cmd+=['-p',f'{k}:={str(v).lower() if isinstance(v,bool) else v}']
    return subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scenario',choices=['demo','random'],default='demo');ap.add_argument('--route',choices=['A','B'],default='A');ap.add_argument('--seed',type=int,default=3);ap.add_argument('--outdir',default='/output/ros_A');ap.add_argument('--max-time',type=float,default=180);ap.add_argument('--fault',choices=['none','mission_kill','scan_drop','estop','competing_publisher'],default='none');args=ap.parse_args()
    rclpy.init();node=WorldNode(args);procs=[];logs=[];env=os.environ.copy();env['CROSSFIRE_RUN_DIR']=args.outdir
    try:
        for executable,params in [
            ('gateway',dict(armed=True,hardware_watchdog_confirmed=True,calibration_confirmed=True,output_topic='/crossfire/sim_cmd',output_mode='yaw_rate',allow_reverse=True,wheelbase=node.world.robot.wheelbase,max_steer=node.world.robot.max_steer,body_length=node.world.robot.length,body_width=node.world.robot.width)),
            ('mission_node',dict(route=args.route,publish_cmd=True,tts='none',config_dir='/workspace/config',**{'topics.scan':'/scan','topics.imu':'/imu/data','topics.odom':'/odom','topics.image':'/usb_cam/image_raw','topics.cmd_vel':'/crossfire/desired_cmd'}))]:
            log=(node.out/f'{executable}.log').open('w');logs.append(log);procs.append(launch_node(executable,params,log,env))
        deadline=time.monotonic()+args.max_time+30;fault_start=None;observations=[]
        while not node.done and time.monotonic()<deadline:
            rclpy.spin_once(node,timeout_sec=.01)
            if args.fault!='none' and node.world.t>4 and (fault_start is not None or abs(node.command[0])>.08):
                if fault_start is None:
                    fault_start=time.monotonic();node.failure_test=dict(start=fault_start,observations=[],initial_command=list(node.command))
                    if args.fault=='mission_kill':os.killpg(procs[1].pid,signal.SIGKILL)
                    if args.fault=='estop':node.estop_pub.publish(Bool(data=True))
                    if args.fault=='competing_publisher':node.competing_pub=node.create_publisher(Twist,'/crossfire/sim_cmd',1)
                if time.monotonic()-fault_start>2:break
            if any(p.poll() is not None for i,p in enumerate(procs) if not(args.fault=='mission_kill' and i==1)):
                raise RuntimeError('ROS2 child exited; inspect logs')
        result=node.finish('fault_test' if fault_start else 'normal' if node.done else 'timeout')
        if fault_start:
            obs=node.failure_test['observations'];zeros=[a[0]-fault_start for a in obs if a[0]>=fault_start and abs(a[1])+abs(a[2])<1e-6]
            late=[a for a in obs if a[0]>fault_start+.65]
            report=dict(fault=args.fault,initial_command=node.failure_test['initial_command'],stopped_speed=abs(node.world.v),first_zero_s=min(zeros) if zeros else None,stayed_zero=bool(late) and all(abs(a[1])+abs(a[2])<1e-6 for a in late),gateway_faults=sorted(set(s[1]['fault'] for s in node.gateway if s[0]>fault_start+.65)))
            report['passed']=abs(report['initial_command'][0])>.08 and bool(zeros) and min(zeros)<.65 and report['stayed_zero'] and report['stopped_speed']<.025
            (node.out/'fault_test.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
            return 0 if report['passed'] else 1
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['success'] else 1
    finally:
        for p in reversed(procs):
            if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
        end=time.monotonic()+4
        for p in procs:
            try:p.wait(timeout=max(.1,end-time.monotonic()))
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        for f in logs:f.close()
        if node.video_proc.poll() is None:
            node.video_proc.stdin.close()
            node.video_proc.wait(timeout=10)
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':sys.exit(main())
