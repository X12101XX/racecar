# 独立实车包 v2

首先阅读 docs/车辆部署指南.md。本包不安装系统依赖或驱动。

1. bash tools/build_car.sh
2. bash tools/run_car.sh A --preflight
3. bash tools/run_car.sh A  # 默认只读，无速度发布者

--arm 仅在完成 profile 全部硬件/场地确认后可用；不要跳过标定。
本包未在当前实车联调，不能声称实车已经完赛。
